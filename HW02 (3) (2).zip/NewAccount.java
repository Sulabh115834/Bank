import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Random;

public class NewAccount {

    private String name;
    private String dateOfBirth;
    private double deposit;
    private int accountNumber;
    private String password;

    // Constructor without deposit
    public NewAccount(String name, String dateOfBirth) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.deposit = 0;
        this.password = generatePassword();
    }

    // Constructor with deposit
    public NewAccount(String name, String dateOfBirth, double deposit) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.deposit = deposit;
        this.password = generatePassword();
    }

    // Generate a random password
    public String generatePassword() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String password = "";
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            int number = random.nextInt(characters.length());
            password = password + characters.charAt(number);
        }

        return password;
    }

    // Check if the person already has an account
    public static boolean accountAlreadyExists(String name, String dateOfBirth)
            throws FileNotFoundException {

        File file = new File("accountInfo.txt");

        if (file.exists() == false) {
            return false;
        }

        Scanner reader = new Scanner(file);

        while (reader.hasNextLine()) {

            // Make sure the five lines for this account are there
            reader.nextLine(); // Account number
            if (reader.hasNextLine() == false) {
                reader.close();
                return false;
            }
            String savedName = reader.nextLine();
            if (reader.hasNextLine() == false) {
                reader.close();
                return false;
            }
            String savedDate = reader.nextLine();
            if (reader.hasNextLine() == false) {
                reader.close();
                return false;
            }
            reader.nextLine(); // Deposit
            if (reader.hasNextLine() == false) {
                reader.close();
                return false;
            }
            reader.nextLine(); // Password

            if (savedName.equalsIgnoreCase(name)
                    && savedDate.equals(dateOfBirth)) {
                reader.close();
                return true;
            }
        }

        reader.close();
        return false;
    }

    // Find the next account number
    public static int findNextAccountNumber()
            throws FileNotFoundException {

        File file = new File("accountInfo.txt");
        int nextNumber = 1001;

        if (file.exists() == false) {
            return nextNumber;
        }

        Scanner reader = new Scanner(file);

        while (reader.hasNextLine()) {

            // Stop if the file has an invalid account number
            if (reader.hasNextInt() == false) {
                reader.close();
                return -1;
            }
            int number = reader.nextInt();
            reader.nextLine();

            // Check that the account has all four remaining lines
            for (int i = 0; i < 4; i++) {
                if (reader.hasNextLine() == false) {
                    reader.close();
                    return -1;
                }
                reader.nextLine();
            }

            if (number >= nextNumber) {
                nextNumber = number + 1;
            }
        }

        reader.close();
        return nextNumber;
    }

    // Save the new account to the file
    public void saveAccount() throws FileNotFoundException {

        File file = new File("accountInfo.txt");
        String oldInfo = "";

        // Read existing account information
        if (file.exists()) {
            Scanner reader = new Scanner(file);

            while (reader.hasNextLine()) {
                oldInfo = oldInfo + reader.nextLine() + "\n";
            }

            reader.close();
        }

        // Write old and new account information
        PrintWriter output = new PrintWriter(file);

        output.print(oldInfo);
        output.println(accountNumber);
        output.println(name);
        output.println(dateOfBirth);
        output.println(deposit);
        output.println(password);

        output.close();
    }

    // Create a new account
    public static void createAccount() {

        Scanner input = new Scanner(System.in);

        System.out.println("Create a Bank Account");

        System.out.print("Enter your name: ");
        String name = input.nextLine();

        System.out.print("Enter your date of birth (MM/DD/YYYY): ");
        String dateOfBirth = input.nextLine();

        try {

            // Check for an existing account
            if (accountAlreadyExists(name, dateOfBirth)) {
                System.out.println("This person already has an account.");
                return;
            }

            System.out.print("Do you want to make a deposit? (yes/no): ");
            String answer = input.nextLine();

            if (answer.equalsIgnoreCase("yes") == false &&
                    answer.equalsIgnoreCase("no") == false) {
                System.out.println("Please enter yes or no.");
                return;
            }

            NewAccount account;

            if (answer.equalsIgnoreCase("yes")) {

                System.out.print("Enter deposit amount: ");

                if (input.hasNextDouble() == false) {
                    System.out.println("Invalid deposit amount.");
                    return;
                }

                double deposit = input.nextDouble();

                if (deposit < 0) {
                    System.out.println("Deposit cannot be negative.");
                    return;
                }

                account = new NewAccount(name, dateOfBirth, deposit);

            } else {
                account = new NewAccount(name, dateOfBirth);
            }

            // Give the account a number
            account.accountNumber = findNextAccountNumber();
            if (account.accountNumber == -1) {
                System.out.println("The account file has incorrect information.");
                return;
            }

            // Save the account
            account.saveAccount();

            System.out.println("Account created successfully!");
            System.out.println("Account Number: " + account.accountNumber);
            System.out.println("Password: " + account.password);
            System.out.println("Deposit: $" + account.deposit);

        } catch (FileNotFoundException e) {
            System.out.println("There was a problem with the account file.");
        }
    }

    public static void main(String[] args) {
        createAccount();
    }
}
